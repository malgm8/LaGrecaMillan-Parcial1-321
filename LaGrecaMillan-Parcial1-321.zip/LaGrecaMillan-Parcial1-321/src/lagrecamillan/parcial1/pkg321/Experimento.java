package lagrecamillan.parcial1.pkg321;

public class Experimento extends UnidadOperativa {

    private int duracionIdeal;

    public Experimento(String nombreId, String modulo, TipoAtmosfera tipoAtmosfera, int duracionIdeal) {
        super(nombreId, modulo, tipoAtmosfera);
        this.duracionIdeal = duracionIdeal;
    }

    @Override
    public String toString() {
        return "Experimento: " + super.toString() + " - Duracion ideal: " + duracionIdeal + " dias";
    }

    @Override
    public void realizarFuncionesBase() {
        System.out.println("Robot reabasteciendose, en condiciones atmosféricas adecuadas y replicandose mediante clonacion de protocolo");
    }

}
