package lagrecamillan.parcial1.pkg321;

public class Robot extends UnidadOperativa implements Movible {

    private int autonomiaOperativa;

    public Robot(String nombreId, String modulo, TipoAtmosfera tipoAtmosfera, int autonomiaOperativa) {
        super(nombreId, modulo, tipoAtmosfera);
        this.autonomiaOperativa = autonomiaOperativa;
    }

    @Override
    public String toString() {
        return "Robot: " + super.toString() + " - Autonomia operativa: " + autonomiaOperativa + " horas";
    }

    
    @Override
    public void mover() {
        int i = 1;
        String cambioModulo = getModulo() + i++;
        System.out.println("Robot trasladado, ahora ubicado en el modulo " + cambioModulo);
    }

    @Override
    public void realizarFuncionesBase() {
        System.out.println("Robot reabasteciendose, en condiciones atmosféricas adecuadas y replicandose mediante copia");
    }

}
