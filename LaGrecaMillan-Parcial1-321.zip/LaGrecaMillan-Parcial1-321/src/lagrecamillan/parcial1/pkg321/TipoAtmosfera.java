package lagrecamillan.parcial1.pkg321;

public enum TipoAtmosfera {

    PRESURIZADA,
    VACIO;

}
