package lagrecamillan.parcial1.pkg321;

import java.util.Objects;

public abstract class UnidadOperativa {

    private String nombreId;
    private String modulo;
    private TipoAtmosfera tipoAtmosfera;

    public UnidadOperativa(String nombreId, String modulo, TipoAtmosfera tipoAtmosfera) {
        this.nombreId = nombreId;
        this.modulo = modulo;
        this.tipoAtmosfera = tipoAtmosfera;
    }

    public String getNombreId() {
        return nombreId;
    }

    public String getModulo(){
        return modulo;
    }
    
    @Override
    public boolean equals(Object o) {
        if ((o == null) || !(o instanceof UnidadOperativa uo)) {
            return false;
        }
        return nombreId.equals(uo.nombreId) && modulo.equals(uo.modulo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombreId, modulo);
    }

    @Override
    public String toString() {
        return "Unidad Operativa - Nombre identificador: " + nombreId + " - Modulo: " + modulo + " - Tipo de atmosfera: " + tipoAtmosfera;
    }

    public abstract void realizarFuncionesBase();

}
