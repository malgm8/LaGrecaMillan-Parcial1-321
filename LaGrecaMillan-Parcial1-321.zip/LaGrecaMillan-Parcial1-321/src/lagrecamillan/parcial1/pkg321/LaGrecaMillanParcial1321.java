package lagrecamillan.parcial1.pkg321;

public class LaGrecaMillanParcial1321 {

    public static void main(String[] args) {
        
        BaseEspacial be = new BaseEspacial("Base Espacial Internacional");
        
        UnidadOperativa a1 = new Astronauta("Cmdr. Vega", "M1", TipoAtmosfera.PRESURIZADA, 5);
        UnidadOperativa a2 = new Astronauta("Cmdr. Louise", "M2", TipoAtmosfera.VACIO, 5);
        UnidadOperativa a3 = new Astronauta("Cmdr. Marvin", "M3", TipoAtmosfera.PRESURIZADA, 8);
        UnidadOperativa r1 = new Robot("Robocop", "M2", TipoAtmosfera.VACIO, 12);
        UnidadOperativa r2 = new Robot("Robotito", "M1", TipoAtmosfera.PRESURIZADA, 6);
        UnidadOperativa r3 = new Robot("Robotron", "M3", TipoAtmosfera.PRESURIZADA, 10);
        UnidadOperativa e1 = new Experimento("EXP123", "M3", TipoAtmosfera.VACIO, 3);
        UnidadOperativa e2 = new Experimento("EXP856", "M2", TipoAtmosfera.PRESURIZADA, 7);
        UnidadOperativa e3 = new Experimento("EXP111", "M1", TipoAtmosfera.PRESURIZADA, 10);
        // UnidadOperativa a4 = new Experimento("Cmdr. Vega", "M1", TipoAtmosfera.PRESURIZADA, 10); // prueba exception
        
        
        
        be.agregarUnidadOperativa(a1);
        be.agregarUnidadOperativa(a2);
        be.agregarUnidadOperativa(a3);
        be.agregarUnidadOperativa(r1);
        be.agregarUnidadOperativa(r2);
        be.agregarUnidadOperativa(r3);
        be.agregarUnidadOperativa(e1);
        be.agregarUnidadOperativa(e2);
        be.agregarUnidadOperativa(e3);
        //be.agregarUnidadOperativa(a4);
        
        be.mostrarUnidades();
        System.out.println("--------------------------------------------------");
        be.moverUnidades();
        System.out.println("--------------------------------------------------");

        
        System.out.println(be.filtrarPorTipoAtmosfera(TipoAtmosfera.VACIO));
        
        
    }
    
}
