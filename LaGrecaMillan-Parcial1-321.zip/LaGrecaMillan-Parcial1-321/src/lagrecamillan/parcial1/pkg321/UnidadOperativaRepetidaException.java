package lagrecamillan.parcial1.pkg321;

public class UnidadOperativaRepetidaException extends RuntimeException {
    
    private static final String MENSAJE = "Unidad operativa repetida";
    
    public UnidadOperativaRepetidaException(){
        super(MENSAJE);
    }
    
    public UnidadOperativaRepetidaException(String mensaje){
        super(mensaje);
    }
}
