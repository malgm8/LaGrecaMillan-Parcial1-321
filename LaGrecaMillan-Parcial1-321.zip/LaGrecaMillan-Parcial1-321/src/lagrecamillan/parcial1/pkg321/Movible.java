package lagrecamillan.parcial1.pkg321;

public interface Movible {
    
    void mover();
}
