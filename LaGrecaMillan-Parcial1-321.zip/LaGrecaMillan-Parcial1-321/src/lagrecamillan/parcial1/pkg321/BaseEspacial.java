package lagrecamillan.parcial1.pkg321;

import java.util.ArrayList;

public class BaseEspacial {

    private String nombre;
    private ArrayList<UnidadOperativa> unidades;

    public BaseEspacial(String nombre) {
        this.nombre = nombre;
        unidades = new ArrayList<>();
    }

    public void agregarUnidadOperativa(UnidadOperativa uo) {
        if (uo == null) {
            throw new IllegalArgumentException("Unidad operativa nula");
        }
        if (unidades.contains(uo)) {
            throw new UnidadOperativaRepetidaException();
        }
        unidades.add(uo);
    }

    public void mostrarUnidades() {
        for (UnidadOperativa uo : unidades) {
            System.out.println(uo.toString());
        }
    }

    public void moverUnidades() {
        for (UnidadOperativa uo : unidades) {
            if (uo instanceof Movible) {
                ((Movible) uo).mover();
                System.out.println(uo.getNombreId() + " ha sido trasladado exitosamente");
            } else {
                System.out.println("No puede ser trasladado porque es un experimento");
            }

        }
    }

    public ArrayList<UnidadOperativa> filtrarPorTipoAtmosfera(TipoAtmosfera tipo) {
        ArrayList<UnidadOperativa> presurizada = new ArrayList<>();
        ArrayList<UnidadOperativa> vacio = new ArrayList<>();
        for (UnidadOperativa uo : unidades) {
            if (tipo == TipoAtmosfera.PRESURIZADA) {
                presurizada.add(uo);
            } else {
                vacio.add(uo);
            }
        }
        return presurizada;
    }

    
    
}
