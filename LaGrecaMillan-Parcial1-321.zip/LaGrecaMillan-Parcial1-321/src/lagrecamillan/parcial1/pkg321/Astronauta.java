package lagrecamillan.parcial1.pkg321;

public class Astronauta extends UnidadOperativa implements Movible {

    private int maxHorasActividad;

    public Astronauta(String nombreId, String modulo, TipoAtmosfera tipoAtmosfera, int maxHorasActividad) {
        super(nombreId, modulo, tipoAtmosfera);
        this.maxHorasActividad = maxHorasActividad;
    }

    @Override
    public String toString() {
        return "Astronauta: " + super.toString() + " - Maximo de horas de actividad: " + maxHorasActividad + " horas";
    }

    @Override
    public void mover() {
        int i = 1;
        String cambioModulo = getModulo() + i++;
        System.out.println("Astronauta trasladado, ahora ubicado en el modulo: " + cambioModulo);
    }

    @Override
    public void realizarFuncionesBase() {
        System.out.println("Astronauta reabasteciendose, en condiciones atmosféricas adecuadas y replicandose mediante entrenamiento");
    }

}
